--Lozada Mendez Ivan--
module Practica02 where
	import Listas
	import Digitos