--Lozada Mendez Ivan--
module Practica01 where
	import Numeros
	import Listas
	import ListasComprension
	import FuncOrdSup
	import Conjuntos